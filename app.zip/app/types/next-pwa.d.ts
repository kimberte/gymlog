declare module "next-pwa" {
  const nextPWA: (config: any) => (nextConfig: any) => any;
  export default nextPWA;
}
