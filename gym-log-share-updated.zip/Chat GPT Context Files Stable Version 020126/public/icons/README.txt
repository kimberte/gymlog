Place gym-app-logo-color-40x40.png here.
